# hl7.fhir.be.core-clinical#1.1.0: Clinical Core(en)

## Pages

* [Transversal](index.md)
* [Changes](changes.md)
* [Artifacts Summary](artifacts.md)
* [Spec](spec.md)
* [Guidance](guidance.md)

## Resources

### CodeSystems

* [Body Site CodeSystem](CodeSystem-be-cs-bodysite.md)
* [Problem Category](CodeSystem-be-cs-problem-category.md)
* [Problem Origin Type](CodeSystem-be-cs-problem-origin-type.md)
* [Score Category](CodeSystem-be-cs-score-category.md)
* [Score Code System](CodeSystem-be-cs-score.md)

### ValueSets

* [Problem Category Value Set](ValueSet-ProblemCategoryVS.md)
* [Problem Code Value Set](ValueSet-ProblemCodeVS.md)
* [Condition Disease Course Value Set](ValueSet-ProblemDiseaseCourseVS.md)
* [BeVSBodyTopography](ValueSet-be-vs-body-topography.md)
* [Body Site](ValueSet-be-vs-bodysite.md)
* [BeVSDiabetesObservationCategory](ValueSet-be-vs-diabetes-observation-category.md)
* [BeVSDiabetesObservationCode](ValueSet-be-vs-diabetes-observation-code.md)
* [BeVSDiabetesReportCategory](ValueSet-be-vs-diabetes-report-category.md)
* [BeVSDiabetesReportStatus](ValueSet-be-vs-diabetes-report-status.md)
* [Laterality](ValueSet-be-vs-laterality.md)
* [Problem Category](ValueSet-be-vs-problem-category.md)
* [Problem Code](ValueSet-be-vs-problem-code.md)
* [Problem Origin Type](ValueSet-be-vs-problem-origin-type.md)
* [Reaction Manifestation Code](ValueSet-be-vs-reaction-manifestation-code.md)
* [Score Value Set](ValueSet-be-vs-score.md)
* [Score Category Value Set](ValueSet-be-vs-scorecategory.md)
* [Severity](ValueSet-be-vs-severity.md)

### Logicals

* [BodySite Model](StructureDefinition-BeModelBodySite.md)
* [BeClinicalObservation Model](StructureDefinition-BeModelClinicalObservation.md)
* [Logical data model for Diabetes Diagnostic Report ](StructureDefinition-BeModelDiagnosticReportDiabetes.md)
* [Diabetes Observation Logical Model](StructureDefinition-BeModelObservationDiabetes.md)
* [Problem Logical Model](StructureDefinition-BeModelProblem.md)
* [BeProcedure Model](StructureDefinition-BeModelProcedure.md)

### Complex-type Profiles

* [BeObservationCodeableConcept](StructureDefinition-be-observationcodeableconcept.md)

### Resource Profiles

* [BeClinicalObservation](StructureDefinition-be-clinical-observation.md)
* [BeDiagnosticReportDiabetes](StructureDefinition-be-diagnostic-report-diabetes.md)
* [BeObservationDiabetes](StructureDefinition-be-observation-diabetes.md)
* [BeObservation](StructureDefinition-be-observation.md)
* [BeProblem](StructureDefinition-be-problem.md)
* [BeProcedure](StructureDefinition-be-procedure.md)
* [BeScoreResult](StructureDefinition-be-scoreresult.md)

### Extensions

* [BeExtRecordedDate](StructureDefinition-BeExtRecordedDate.md)
* [BeExtBodyTopography](StructureDefinition-be-ext-body-topography.md)
* [BeExtLaterality](StructureDefinition-be-ext-laterality.md)
* [BeExtProblemOriginType](StructureDefinition-be-ext-problem-origin-type.md)
* [Surgical Approach](StructureDefinition-be-ext-surgical-approach.md)

### ImplementationGuides

* [Clinical Core](ImplementationGuide-hl7.fhir.be.core-clinical.md)

### NamingSystems

* [BeNSDiabetesDeviceType](NamingSystem-be-ns-diabetes-device-type.md)
* [BeNSDiagnosticReportDiabetes](NamingSystem-be-ns-diagnostic-report-diabetes.md)
* [BeNSObservationDiabetes](NamingSystem-be-ns-observation-diabetes.md)

### Examples

* [uc52-bundle (Bundle)](Bundle-uc52-bundle.md)
* [uc53-bundle (Bundle)](Bundle-uc53-bundle.md)
* [Diabetes device report (Composition)](Composition-uc52-composition.md)
* [Diabetes device report (Composition)](Composition-uc53-composition.md)
* [device (Device)](Device-device.md)
* [uc52-pdfonly (DiagnosticReport)](DiagnosticReport-uc52-pdfonly.md)
* [uc53-pdf-derived (DiagnosticReport)](DiagnosticReport-uc53-pdf-derived.md)
* [397dffb4-a88a-47d0-b10d-beffcbf6157d (Observation)](Observation-397dffb4-a88a-47d0-b10d-beffcbf6157d.md)
* [449a728d-dfb4-422d-94aa-1a2d43849ee5 (Observation)](Observation-449a728d-dfb4-422d-94aa-1a2d43849ee5.md)
* [454a29d0-0893-458a-b2e5-25452b89e29a (Observation)](Observation-454a29d0-0893-458a-b2e5-25452b89e29a.md)
* [6756477d-b57a-4611-b048-374d46f52908 (Observation)](Observation-6756477d-b57a-4611-b048-374d46f52908.md)
* [a6665182-e11a-40a9-ae83-9b093a353f16 (Observation)](Observation-a6665182-e11a-40a9-ae83-9b093a353f16.md)
* [b28ef33b-0480-4bde-a5df-94988813110b (Observation)](Observation-b28ef33b-0480-4bde-a5df-94988813110b.md)
* [b44fe5d5-f57b-4424-b628-d2baeb447738 (Observation)](Observation-b44fe5d5-f57b-4424-b628-d2baeb447738.md)
* [c611b58d-27bb-49e2-b3ec-bd59e986f5f3 (Observation)](Observation-c611b58d-27bb-49e2-b3ec-bd59e986f5f3.md)
