# BeExtLaterality - Clinical Core v1.2.0

## Extension: BeExtLaterality 

An explicit statement of laterality of a lesion, or a treatment, etc.

**Context of Use**

**Usage info**

**Usages:**

* Use this Extension: [BeClinicalObservation](StructureDefinition-be-clinical-observation.md), [BeDeviceUseStatement](StructureDefinition-be-device-use-statement.md), [BeProblem](StructureDefinition-be-problem.md), [BeProcedure](StructureDefinition-be-procedure.md) and [BeScoreResult](StructureDefinition-be-scoreresult.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/hl7.fhir.be.core-clinical|current/StructureDefinition/StructureDefinition-be-ext-laterality.json)

### Formal Views of Extension Content

 [Description Differentials, Snapshots, and other representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-be-ext-laterality.csv), [Excel](../StructureDefinition-be-ext-laterality.xlsx), [Schematron](../StructureDefinition-be-ext-laterality.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "be-ext-laterality",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 1
  }],
  "url" : "https://www.ehealth.fgov.be/standards/fhir/core-clinical/StructureDefinition/be-ext-laterality",
  "version" : "1.2.0",
  "name" : "BeExtLaterality",
  "title" : "BeExtLaterality",
  "status" : "active",
  "date" : "2026-08-31T14:48:40+00:00",
  "publisher" : "eHealth Platform",
  "contact" : [{
    "name" : "eHealth Platform",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.ehealth.fgov.be"
    },
    {
      "system" : "email",
      "value" : "message-structure@www.ehealth.fgov.be"
    }]
  },
  {
    "name" : "Message-Structure",
    "telecom" : [{
      "system" : "email",
      "value" : "message-structure@www.ehealth.fgov.be",
      "use" : "work"
    }]
  }],
  "description" : "An explicit statement of laterality of a lesion, or a treatment, etc.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "BE",
      "display" : "Belgium"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [{
    "type" : "element",
    "expression" : "Claim.item.bodySite"
  },
  {
    "type" : "element",
    "expression" : "Condition.bodySite"
  },
  {
    "type" : "element",
    "expression" : "Immunization.site"
  },
  {
    "type" : "element",
    "expression" : "Observation.bodySite"
  },
  {
    "type" : "element",
    "expression" : "ServiceRequest.bodySite"
  },
  {
    "type" : "element",
    "expression" : "DeviceUseStatement.bodySite"
  },
  {
    "type" : "element",
    "expression" : "Procedure.bodySite"
  }],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Extension",
      "path" : "Extension",
      "short" : "BeExtLaterality",
      "definition" : "An explicit statement of laterality of a lesion, or a treatment, etc."
    },
    {
      "id" : "Extension.extension",
      "path" : "Extension.extension",
      "max" : "0"
    },
    {
      "id" : "Extension.url",
      "path" : "Extension.url",
      "fixedUri" : "https://www.ehealth.fgov.be/standards/fhir/core-clinical/StructureDefinition/be-ext-laterality"
    },
    {
      "id" : "Extension.value[x]",
      "path" : "Extension.value[x]",
      "type" : [{
        "code" : "Coding"
      }],
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://www.ehealth.fgov.be/standards/fhir/terminology/ValueSet/be-vs-laterality"
      }
    }]
  }
}

```
