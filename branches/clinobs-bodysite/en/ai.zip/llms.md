# hl7.fhir.be.core-clinical#1.3.0: Clinical Core(en)

## Pages

* [Transversal](index.md)
* [Changes](changes.md)
* [Guidance](guidance.md)
* [Artifacts Summary](artifacts.md)
* [Spec](spec.md)

## Resources

### CodeSystems

* [Body Site CodeSystem](CodeSystem-be-cs-bodysite.md)
* [Problem Category](CodeSystem-be-cs-problem-category.md)
* [Problem Origin Type](CodeSystem-be-cs-problem-origin-type.md)
* [Score Category](CodeSystem-be-cs-score-category.md)
* [Score Code System](CodeSystem-be-cs-score.md)

### ValueSets

* [Problem Category Value Set](ValueSet-ProblemCategoryVS.md)
* [Problem Code Value Set](ValueSet-ProblemCodeVS.md)
* [Condition Disease Course Value Set](ValueSet-ProblemDiseaseCourseVS.md)
* [Body Topography ValueSet](ValueSet-be-vs-body-topography.md)
* [Body Site ValueSet](ValueSet-be-vs-bodysite.md)
* [Laterality ValueSet](ValueSet-be-vs-laterality.md)
* [Problem Category ValueSet](ValueSet-be-vs-problem-category.md)
* [Problem Code ValueSet](ValueSet-be-vs-problem-code.md)
* [Problem Origin Type ValueSet](ValueSet-be-vs-problem-origin-type.md)
* [Reaction Manifestation Code ValueSet](ValueSet-be-vs-reaction-manifestation-code.md)
* [Score ValueSet](ValueSet-be-vs-score.md)
* [Score Category ValueSet](ValueSet-be-vs-scorecategory.md)
* [Severity ValueSet](ValueSet-be-vs-severity.md)

### Logicals

* [BodySite Model](StructureDefinition-BeModelBodySite.md)
* [BeClinicalObservation Model](StructureDefinition-BeModelClinicalObservation.md)
* [Problem Logical Model](StructureDefinition-BeModelProblem.md)
* [BeProcedure Model](StructureDefinition-BeModelProcedure.md)

### Complex-type Profiles

* [BeObservationCodeableConcept](StructureDefinition-be-observationcodeableconcept.md)

### Resource Profiles

* [BeClinicalObservation](StructureDefinition-be-clinical-observation.md)
* [BeObservation](StructureDefinition-be-observation.md)
* [BeProblem](StructureDefinition-be-problem.md)
* [BeProcedure](StructureDefinition-be-procedure.md)
* [BeScoreResult](StructureDefinition-be-scoreresult.md)

### Extensions

* [BeExtBodyTopography](StructureDefinition-be-ext-body-topography.md)
* [BeExtLaterality](StructureDefinition-be-ext-laterality.md)
* [BeExtProblemOriginType](StructureDefinition-be-ext-problem-origin-type.md)
* [Surgical Approach](StructureDefinition-be-ext-surgical-approach.md)

### ImplementationGuides

* [Clinical Core](ImplementationGuide-hl7.fhir.be.core-clinical.md)
