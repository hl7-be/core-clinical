# Spec - HL7 FHIR Implementation Guide: Transversal Clinical Core v1.0.1

* [**Table of Contents**](toc.md)
* **Spec**

## Spec

### Specifications

These are the project specifications:

