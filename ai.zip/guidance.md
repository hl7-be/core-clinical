# Guidance - Clinical Core v1.1.0

* [**Table of Contents**](toc.md)
* **Guidance**

## Guidance

### Scope

 The scope of this package is to bundle all concepts and other FHIR resources that are transversal, and thus can be used in other, more specific packages and that are medical in nature, rather than purely administrative. The purely administrative resources are defined in hl7.fhir.be.core . 

