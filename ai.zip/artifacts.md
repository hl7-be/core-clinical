# Artifacts Summary - Clinical Core v1.1.0

* [**Table of Contents**](toc.md)
* **Artifacts Summary**

## Artifacts Summary

This page provides a list of the FHIR artifacts defined as part of this implementation guide.

### Structures: Logical Models 

These define data models that represent the domain covered by this implementation guide in more business-friendly terms than the underlying FHIR resources.

| | |
| :--- | :--- |
| [BeClinicalObservation Model](StructureDefinition-BeModelClinicalObservation.md) | Clinical Observation logical model |
| [BeProcedure Model](StructureDefinition-BeModelProcedure.md) | Procedure logical model |
| [BodySite Model](StructureDefinition-BeModelBodySite.md) | Body site model |
| [Problem Logical Model](StructureDefinition-BeModelProblem.md) | Logical model for Problem |

### Structures: Resource Profiles 

These define constraints on FHIR resources for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [BeClinicalObservation](StructureDefinition-be-clinical-observation.md) | Belgian federal profile for a clinical observation. |
| [BeObservation](StructureDefinition-be-observation.md) | Belgian federal profile for an observation. Initially based on the functional description of the NIHDI. As Observation is used in many instances in FHIR, please refer to the HL7 specs of the base resource for guidance around expression of actual values using UCUM, methods, location on body etc.Special remarks for KMEHR users: The FHIR Observation resource captures many things that are in a KMEHR message structured as an ‘item’. This includes things like ‘vital signs such as body weight, blood pressure, and temperature […], personal characteristics such as eye-color […] social history like tobacco use, family support, or cognitive status […]’ ( https://www.hl7.org/fhir/R4/observation.html ) For some of these things, HL7 already has worked out profiles and they SHALL be used when such a use case is needed. Specifically, projects SHALL take note of the existing profiles described on https://www.hl7.org/fhir/R4/observation-vitalsigns.html |
| [BeProblem](StructureDefinition-be-problem.md) | A condition, diagnosis or situation that is the focus of care. |
| [BeProcedure](StructureDefinition-be-procedure.md) | Placeholder profile for contextualising the FHIR resource |
| [BeScoreResult](StructureDefinition-be-scoreresult.md) | To support the standard exchange of scores such as pain assessment scores, or risk score, etc |

### Structures: Data Type Profiles 

These define constraints on FHIR data types for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [BeObservationCodeableConcept](StructureDefinition-be-observationcodeableconcept.md) | This is a supporting profile, only to give guidelines how to express a few of the typical coding systems. In general, it shall be noted SNOMED-CT is the preferred national terminology. Other coding systems remain allowed or MAY be preferred in specific flows (e.g. the use of LOINC codes to express a laboratory test.) |

### Structures: Extension Definitions 

These define constraints on FHIR data types for systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [BeExtBodyTopography](StructureDefinition-be-ext-body-topography.md) | Describes the location or relative position on the body, such as superior/inferior, medial/lateral or internal/external. |
| [BeExtLaterality](StructureDefinition-be-ext-laterality.md) | An explicit statement of laterality of a lesion, or a treatment, etc. |
| [BeExtProblemOriginType](StructureDefinition-be-ext-problem-origin-type.md) | The type of event that triggers the problem to be evaluated - whether the problem was reported from a referring GP, etc… |
| [Surgical Approach](StructureDefinition-be-ext-surgical-approach.md) | The surgical approach used for the procedure. |

### Terminology: Value Sets 

These define sets of codes used by systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [BeVSBodyTopography](ValueSet-be-vs-body-topography.md) | Body topography value set - describes the location or relative position on the body (e.g., superior/inferior, medial/lateral, internal/external). Placeholder valueset - the normative definition will be published in the Belgian terminology IG. |
| [Body Site](ValueSet-be-vs-bodysite.md) | Body Site - placeholder valueset - the normative definition will be published in the Belgian terminology IG. |
| [Condition Disease Course Value Set](ValueSet-ProblemDiseaseCourseVS.md) | Condition Disease Course |
| [Laterality](ValueSet-be-vs-laterality.md) | Laterality - placeholder valueset - the normative definition will be published in the Belgian terminology IG. |
| [Problem Category](ValueSet-be-vs-problem-category.md) | Problem Category - placeholder valueset - the normative definition will be published in the Belgian terminology IG. |
| [Problem Category Value Set](ValueSet-ProblemCategoryVS.md) | Category of the problem |
| [Problem Code](ValueSet-be-vs-problem-code.md) | Problem Code - placeholder valueset - the normative definition will be published in the Belgian terminology IG. |
| [Problem Code Value Set](ValueSet-ProblemCodeVS.md) | Code of the problem |
| [Problem Origin Type](ValueSet-be-vs-problem-origin-type.md) | Problem Origin Type |
| [Reaction Manifestation Code](ValueSet-be-vs-reaction-manifestation-code.md) | Reaction Manifestation Code (Allergy - Immunization) |
| [Score Category Value Set](ValueSet-be-vs-scorecategory.md) | Score Category Value Set |
| [Score Value Set](ValueSet-be-vs-score.md) | Codes as defined by the NIHDI. Dutch translations are expected for a next release. |
| [Severity](ValueSet-be-vs-severity.md) | Severity - placeholder valueset - the normative definition will be published in the Belgian terminology IG. |

### Terminology: Code Systems 

These define new code systems used by systems conforming to this implementation guide.

| | |
| :--- | :--- |
| [Body Site CodeSystem](CodeSystem-be-cs-bodysite.md) | Body Site CodeSystem |
| [Problem Category](CodeSystem-be-cs-problem-category.md) | Problem Category |
| [Problem Origin Type](CodeSystem-be-cs-problem-origin-type.md) | Problem Origin Type |
| [Score Category](CodeSystem-be-cs-score-category.md) | Score Category |
| [Score Code System](CodeSystem-be-cs-score.md) | Codes as defined initially by the NIHDI. Dutch translations were not yet defined but are planned for a next release. |

